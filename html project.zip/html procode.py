
for i in range(1,9):
    print(" <a href='#/Action1' class='button'>E"+ str(i) +"</a>")
 